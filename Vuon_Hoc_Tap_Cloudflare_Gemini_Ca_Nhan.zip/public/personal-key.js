/* Gemini credentials live only in aiTutor.code, outside the learning state. */
function tutorForgetPersonalKey(){tutorInvalidate();aiTutor.code='';const input=document.getElementById('tutorCode');if(input)input.value='';}
actions.tutorForgetKey=()=>{tutorForgetPersonalKey();readerRefresh();toast('Đã xóa khóa Gemini khỏi phiên này.');};
const personalTutorPanelBefore=tutorPanel;
tutorPanel=function(){return personalTutorPanelBefore()
 .replace('Mã truy cập gia sư','Khóa Gemini cá nhân')
 .replace('Mã do chủ website cung cấp','Nhập API key của bạn')
 .replace('Mã truy cập khác khóa API. Không nhập khóa Gemini tại đây.','Khóa chỉ giữ trong bộ nhớ của tab. Tải lại trang hoặc đăng xuất sẽ xóa khóa. Chỉ đề đã chọn được gửi tới Google khi bạn yêu cầu AI.')
 .replace('id="tutorCode" type="password" value="'+esc(aiTutor.code)+'"','id="tutorCode" type="password" value=""')
 .replace('</small></div><p class="tutor-privacy">','</small><button class="btn ghost" data-action="tutorForgetKey">Xóa khóa khỏi phiên</button></div><p class="tutor-privacy">')
 .replace('AI cần website có máy chủ đã cấu hình Gemini.','AI dùng khóa cá nhân qua máy chủ Cloudflare. Mỗi khóa chịu hạn mức của dự án Google tương ứng.');};
// Populate a password input as a DOM property; never place the key in HTML markup.
const personalReaderUpdateBefore=readerUpdate;
readerUpdate=function(){personalReaderUpdateBefore.apply(this,arguments);const input=document.getElementById('tutorCode');if(input)input.value=aiTutor.code;};
window.addEventListener('pagehide',tutorForgetPersonalKey);
// Account actions must use server-side account management in the online build.
