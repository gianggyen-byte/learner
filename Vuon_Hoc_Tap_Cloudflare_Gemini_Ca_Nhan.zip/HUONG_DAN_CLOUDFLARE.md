# Vườn học tập — Cloudflare và Gemini cá nhân

Bản này giữ giao diện, bài học, luyện tập, thi thử, mindmap, khu vườn và gia sư của file index.html hiện tại. Phần đăng nhập chuyển sang tài khoản online bằng Cloudflare D1. Gemini sử dụng khóa riêng của học sinh.

Đây là mã sẵn để triển khai. Gói tải về chưa tự tạo tài khoản Cloudflare, database hay website đang chạy.

## 1. Chuẩn bị trên GitHub

1. Giải nén gói ZIP trên máy tính
2. Mở repository GitHub `gianggyen-byte/vuon-hoc-tap`
3. Chọn Add file → Upload files
4. Kéo các thư mục `public`, `functions`, `lib`, `migrations`, `scripts` cùng `package.json`, `.gitignore` và hướng dẫn này vào trang tải lên. Kéo NỘI DUNG bên trong thư mục đã giải nén, không tải cả ZIP và không tạo thêm một tầng thư mục ngoài
5. Commit changes
6. Kiểm tra file trang chủ nằm đúng `public/index.html` và Function nằm đúng `functions/api/[[path]].js`

Các file `netlify.toml` và thư mục `netlify` cũ không được Cloudflare dùng. Chưa cần xóa chúng. Không tải API key lên GitHub.

## 2. Tạo database Cloudflare D1

1. Đăng nhập https://dash.cloudflare.com/
2. Mở Storage & databases → D1 SQL Database. Nếu tên menu khác, tìm D1
3. Chọn Create database, đặt tên `vuon-hoc-tap-db`, rồi tạo
4. Mở database → Console
5. Mở file `migrations/0001_accounts.sql` trong gói bằng trình soạn thảo
6. Sao chép toàn bộ nội dung SQL vào Console và Execute. Chỉ thực hiện trên DATABASE MỚI, chưa chứa bảng hoặc dữ liệu
7. Kiểm tra có 5 bảng: `users`, `sessions`, `progress`, `progress_backups`, `rate_limits`

Nếu Console chỉ nhận từng lệnh, lần lượt chạy từng câu CREATE trong file. Không chạy lệnh xóa bảng để sửa lỗi. Có thể dùng công cụ Wrangler thay cho Console với lệnh dưới đây, sau khi đăng nhập tài khoản Cloudflare và xác nhận đúng database:

```bash
npx wrangler d1 execute vuon-hoc-tap-db --remote --file=migrations/0001_accounts.sql
```

## 3. Tạo Cloudflare Pages từ GitHub hiện tại

1. Trong Cloudflare mở Workers & Pages → Create application
2. Chọn Pages → Connect to Git hoặc Import an existing Git repository. Nếu giao diện mặc định mở Workers, chuyển sang Pages
3. Kết nối GitHub và cấp quyền cho repository `vuon-hoc-tap`
4. Chọn repository đó, production branch `main`
5. Đặt thông số:

| Mục | Giá trị |
|---|---|
| Project name | `vuon-hoc-tap` hoặc tên còn trống |
| Framework preset | None |
| Build command | `npm run build` |
| Build output directory | `public` |
| Root directory | Để trống nếu các thư mục đã đặt ở ngoài cùng repository |

6. Save and Deploy
7. Giữ URL HTTPS được Cloudflare cấp. Nếu chưa gắn database, đăng nhập sẽ báo chưa kết nối database. Đây là bước thiết lập tiếp theo

Không dùng hình thức chỉ kéo HTML vào trang Direct Upload để triển khai Functions. Gói này dành cho Pages kết nối GitHub.

## 4. Gắn database và chọn mô hình Gemini

Trong dự án Pages vừa tạo:

1. Settings → Bindings → Add → D1 database binding
2. Variable name nhập chính xác `DB`, viết hoa
3. Chọn database `vuon-hoc-tap-db`, lưu lại cho môi trường Production
4. Mở Settings → Variables and Secrets
5. Thêm biến `GEMINI_MODEL`. Giá trị là mã mô hình Gemini hỗ trợ generateContent và JSON có cấu trúc, đúng theo Google AI Studio. Dùng mã API, không dùng nhãn tên hiển thị và không dán API key vào đây
6. Ví dụ `gemini-3.8-flash` chỉ dùng nếu mô hình này đang được cấp cho các dự án Google của người học. Khả năng sử dụng mô hình và hạn mức phụ thuộc dự án Google
7. Không cần khai báo `GEMINI_API_KEY` hoặc `TUTOR_ACCESS_CODE` cho bản này
8. Mở Deployments → chọn lần triển khai mới nhất → Retry deployment để bản chạy nhận binding và biến mới. Nếu dùng Preview, cấu hình Preview với database thử nghiệm riêng

## 5. Kiểm tra tài khoản và gia sư

1. Mở URL HTTPS của Pages. Bấm tạo tài khoản, nhập tên không dấu 3–30 ký tự và mật khẩu 8–128 ký tự
2. Chọn cây, mục tiêu và học thử một phần
3. Trong menu tên người dùng, bấm Đồng bộ và đợi trạng thái Đã đồng bộ
4. Mở cùng URL trong cửa sổ ẩn danh hoặc thiết bị khác, đăng nhập cùng tài khoản và kiểm tra tiến độ
5. Mở Gia sư AI → Nhập tài liệu. Nhập đề `Giải phương trình x² − 5x + 6 = 0`
6. Chuyển sang Gia sư giải bài toán, kiểm tra đề và đánh dấu xác nhận
7. Bấm Kiểm tra kết nối gia sư. Nút này chỉ kiểm tra cấu hình máy chủ, không gọi Gemini và không xác minh khóa
8. Nhập API key cá nhân từ https://aistudio.google.com/api-keys vào ô Khóa Gemini cá nhân, rồi bấm AI hướng dẫn giải
9. Thử nút Xóa khóa khỏi phiên. Tải lại trang cũng phải yêu cầu nhập lại khóa
10. Mỗi học sinh dùng khóa của mình. Không gửi khóa cho chủ website và không chụp ảnh hoặc chia sẻ khóa

Khóa chỉ nằm trong bộ nhớ tab và được gửi qua HTTPS bằng header tới Function cùng origin. Function chỉ dùng khóa để gọi endpoint Google cố định, không lưu vào D1, localStorage hoặc sessionStorage, không ghi nội dung khóa vào log ứng dụng. Không bật ghi log toàn bộ header/yêu cầu ở Cloudflare. Google xử lý nội dung theo chính sách của dịch vụ Gemini đang sử dụng. Đây là lời đọc tổng hợp của thiết bị và AI hướng dẫn giải, không phải ghi âm phát lại.

Khóa trong bộ nhớ vẫn có thể bị mã độc trong trang hoặc trên thiết bị lấy được. Cần giữ mã website và thiết bị tin cậy. Giới hạn khóa cho Gemini API trong Google Cloud khi phù hợp. Mỗi dự án Google có hạn mức riêng, nhiều khóa cùng một dự án có thể dùng chung hạn mức.

## 6. Tiến độ cũ và thiết bị khác

- Dữ liệu cũ chỉ lưu trên trình duyệt không tự chuyển sang domain mới
- Ở web cũ, dùng Tải bản sao tiến độ để xuất JSON
- Ở trang đăng nhập mới, bấm Chuyển tài khoản / nhập tiến độ cũ, chọn JSON và tạo tài khoản online từ tiến độ đó
- Không thể đọc localStorage của domain Netlify từ domain Cloudflare
- Nếu đã có tài khoản online, không tạo trùng tên để ghi đè. Bản này có nhập tiến độ lúc tạo tài khoản mới
- Khi hai thiết bị cùng sửa tiến độ, web cho chọn bản trên thiết bị hoặc bản trên web, không tự ghi đè bản mới
- Mất mạng: giữ bản chờ đồng bộ theo tài khoản trên thiết bị. Bản lưu tạm không chứa API key hoặc mật khẩu
- Database giữ tối đa 10 phiên bản tiến độ trước đó. Bản này chưa có trang quản trị khôi phục các phiên bản
- Có đổi mật khẩu và xóa tài khoản sau khi xác nhận. Chưa có quên mật khẩu qua email, chưa có xác minh email hoặc quản lý lớp học

## 7. Lỗi thường gặp

| Thông báo / mã | Cách xử lý |
|---|---|
| Database chưa sẵn sàng | Kiểm tra binding tên DB, chọn đúng D1, tạo đủ bảng rồi redeploy |
| Chưa tìm thấy máy chủ gia sư | Kiểm tra functions/api/[[path]].js có trong GitHub và dùng Pages Git integration |
| CONFIG_MISSING | Kiểm tra DB và GEMINI_MODEL, redeploy |
| SESSION_EXPIRED | Đăng nhập lại tài khoản rồi nhập lại khóa |
| KEY_REQUIRED / API_KEY_INVALID | Xóa và nhập lại đúng API key cá nhân, không nhập mật khẩu tài khoản |
| MODEL_NOT_FOUND | Chủ web sửa GEMINI_MODEL theo mô hình hỗ trợ, redeploy |
| AUTH_DENIED / API_NOT_ENABLED | Kiểm tra dự án Google chứa khóa, API đã bật và giới hạn khóa phù hợp gọi từ máy chủ |
| QUOTA_EXCEEDED | Chủ khóa kiểm tra hạn mức đúng dự án Google. Không bấm gửi lặp liên tục |
| RATE_LIMITED | Website giới hạn 10 yêu cầu AI / phút theo tài khoản và IP. Chờ rồi thử lại |
| Có hai bản tiến độ | Đọc thông tin, tải bản sao nếu cần, chọn bản muốn tiếp tục |

## 8. Giới hạn và xác nhận kiểm tra

Đã chạy kiểm thử backend bằng SQLite mô phỏng D1 và Gemini giả lập, kiểm tra cookie đăng nhập, tách tài khoản, đổi mật khẩu, thu hồi phiên, đồng bộ hai thiết bị, xung đột, lưu lại sau mất mạng, hai khóa cá nhân khác nhau, xóa khóa, từ chối lưu khóa vào tiến độ và xử lý lỗi Google không lộ khóa.

Chưa kiểm thử bằng API key thật hoặc triển khai vào tài khoản Cloudflare của bạn. Sau khi tạo tài nguyên cần kiểm tra trực tiếp theo mục 5. Gói miễn phí Cloudflare và Gemini vẫn có hạn mức. Lượng truy cập, truy vấn database và yêu cầu AI phải được theo dõi khi đưa vào sử dụng thực tế.

Tài liệu chính thức:
- https://developers.cloudflare.com/pages/get-started/git-integration/
- https://developers.cloudflare.com/pages/functions/bindings/
- https://developers.cloudflare.com/d1/get-started/
- https://developers.cloudflare.com/pages/platform/limits/
- https://ai.google.dev/gemini-api/docs/api-key

Sau khi kiểm tra Cloudflare hoạt động đầy đủ, cập nhật link chia sẻ sang URL mới. Tên miền *.netlify.app thuộc Netlify nên không chuyển nguyên địa chỉ đó sang Cloudflare. Nếu có tên miền riêng, có thể cấu hình lại trên Cloudflare sau khi xác minh quyền sở hữu. Chỉ ngắt triển khai Netlify sau khi xác nhận bản mới chạy tốt.
